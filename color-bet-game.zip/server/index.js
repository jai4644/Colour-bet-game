const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
app.use(cors());
app.use(bodyParser.json());

let users = [];
let rounds = [];
let nextRoundId = 1;

const ADMIN = { username: 'admin', password: 'admin123' };

app.post('/register', (req, res) => {
  const { username, password } = req.body;
  if (users.find(u => u.username === username)) {
    return res.status(400).json({ message: 'Username exists' });
  }
  users.push({ username, password, balance: 100 });
  res.json({ message: 'Registered', balance: 100 });
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const user = users.find(u => u.username === username && u.password === password);
  if (!user) return res.status(401).json({ message: 'Invalid credentials' });
  res.json({ message: 'Logged in', balance: user.balance });
});

app.post('/bet', (req, res) => {
  const { username, color, amount } = req.body;
  const user = users.find(u => u.username === username);
  if (!user) return res.status(401).json({ message: 'User not found' });
  if (user.balance < amount) return res.status(400).json({ message: 'Insufficient balance' });

  const resultColor = ['red', 'green', 'blue'][Math.floor(Math.random() * 3)];
  const win = (color === resultColor);
  user.balance += win ? amount : -amount;
  rounds.push({ id: nextRoundId++, username, color, amount, resultColor, win });
  res.json({ resultColor, win, balance: user.balance });
});

app.get('/rounds', (req, res) => {
  res.json(rounds);
});

app.post('/admin/login', (req, res) => {
  const { username, password } = req.body;
  if (username === ADMIN.username && password === ADMIN.password) {
    res.json({ message: 'Admin logged in' });
  } else {
    res.status(401).json({ message: 'Invalid admin credentials' });
  }
});

app.get('/admin/users', (req, res) => {
  res.json(users);
});

app.post('/admin/set-result', (req, res) => {
  const { roundId, resultColor } = req.body;
  const round = rounds.find(r => r.id === roundId);
  if (!round) return res.status(404).json({ message: 'Round not found' });
  round.resultColor = resultColor;
  round.win = (round.color === resultColor);
  const user = users.find(u => u.username === round.username);
  if (user) {
    user.balance += round.win ? round.amount * 2 : -round.amount;
  }
  res.json({ message: 'Result set', round });
});

// Serve frontend
app.use(express.static(path.join(__dirname, '../client/build')));
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../client/build/index.html'));
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
