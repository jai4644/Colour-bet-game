# 🎮 Color Bet Game (Fullstack App)

This is a fullstack betting game built with React (frontend) and Express.js (backend). It allows user registration, login, and betting on color outcomes. Includes an admin panel to view and manage game rounds.

## 🚀 Deploying to Render

1. **Push this project to GitHub**

2. **Go to [https://render.com](https://render.com)**

3. **Click "New Web Service" → Connect your GitHub repo**

4. **Select this repo**

5. Render will detect the `render.yaml` and auto-configure everything.

6. Deploy and enjoy! 🎉

---

## 🗂 Folder Structure

- `/client` → React frontend
- `/server` → Express backend
- `render.yaml` → Deployment instructions
